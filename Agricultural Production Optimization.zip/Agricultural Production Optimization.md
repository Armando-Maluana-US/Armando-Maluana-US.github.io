# Import Libraries


```python
# for manipuation
import numpy as np
import pandas as pd

#for data visualizations
import matplotlib.pyplot as plt
import seaborn as sns

#for interactivity
from ipywidgets import interact

```


```python
#lets read the dataset
data = pd.read_csv("data.csv")
```


```python
#lets Check the shape of the dataset
print("shape of the Dataset:", data.shape)
```

    shape of the Dataset: (2200, 8)
    


```python
#Lets check the content of the dataset
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>N</th>
      <th>P</th>
      <th>K</th>
      <th>temperature</th>
      <th>humidity</th>
      <th>ph</th>
      <th>rainfall</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>90</td>
      <td>42</td>
      <td>43</td>
      <td>20.879744</td>
      <td>82.002744</td>
      <td>6.502985</td>
      <td>202.935536</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>1</th>
      <td>85</td>
      <td>58</td>
      <td>41</td>
      <td>21.770462</td>
      <td>80.319644</td>
      <td>7.038096</td>
      <td>226.655537</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>55</td>
      <td>44</td>
      <td>23.004459</td>
      <td>82.320763</td>
      <td>7.840207</td>
      <td>263.964248</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>3</th>
      <td>74</td>
      <td>35</td>
      <td>40</td>
      <td>26.491096</td>
      <td>80.158363</td>
      <td>6.980401</td>
      <td>242.864034</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>4</th>
      <td>78</td>
      <td>42</td>
      <td>42</td>
      <td>20.130175</td>
      <td>81.604873</td>
      <td>7.628473</td>
      <td>262.717340</td>
      <td>rice</td>
    </tr>
  </tbody>
</table>
</div>




```python
#lets check if ther is any missing value present in the dataset
#if there missing values you can use the fillin function. you can use:
  #Mean-numerical values, 
  #Median - If the calues are the dataset contains large numbers of utliers.
  #Mode-If the values are categorrical
data.isnull().sum()
```




    N              0
    P              0
    K              0
    temperature    0
    humidity       0
    ph             0
    rainfall       0
    label          0
    dtype: int64




```python
#Lets check the Crops present in the Dataset
data["label"].value_counts()
```




    rice           100
    maize          100
    jute           100
    cotton         100
    coconut        100
    papaya         100
    orange         100
    apple          100
    muskmelon      100
    watermelon     100
    grapes         100
    mango          100
    banana         100
    pomegranate    100
    lentil         100
    blackgram      100
    mungbean       100
    mothbeans      100
    pigeonpeas     100
    kidneybeans    100
    chickpea       100
    coffee         100
    Name: label, dtype: int64




```python
#Lets check the sumary for all the Crops
print("Average Ratio of Nitrogen in the Soil: {0:.2f}".format(data["N"].mean()))
print("Average Ratio of Phosphorous in the Soil: {0:.2f}".format(data["P"].mean()))
print("Average Ratio of Potassium in the Soil: {0:.2f}".format(data["K"].mean()))
print("Average Temperature in Celsius: {0:.2f}".format(data["temperature"].mean()))
print("Average Relative Humidity in %: {0:.2f}".format(data["humidity"].mean()))
print("Average PH of the Soil: {0:.2f}".format(data["ph"].mean()))
print("Average Rainfall in mm: {0:.2f}".format(data["rainfall"].mean()))
```

    Average Ratio of Nitrogen in the Soil: 50.55
    Average Ratio of Phosphorous in the Soil: 53.36
    Average Ratio of Potassium in the Soil: 48.15
    Average Temperature in Celsius: 25.62
    Average Relative Humidity in %: 71.48
    Average PH of the Soil: 6.47
    Average Rainfall in mm: 103.46
    


```python
# Lets check the Summary Statistics for each of the Crops
#use the dropdown menu below to select individual crop
@interact
def summary(crops = list(data["label"].value_counts().index)):
    X = data[data["label"] == crops] 
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Nitrogen" + "\033[0m")
    print("Minimum Nitrogen required :", X["N"].min())
    print("Minimum Nitrogen required :", X["N"].mean())
    print("Maximum Nitrogen required :", X["N"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Phosphorous" + "\033[0m")
    print("Minimum Phosphorous required :", X["P"].min())
    print("Minimum Phosphorous required :", X["P"].mean())
    print("Maximum Phosphorous required :", X["P"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Potassium" + "\033[0m")
    print("Minimum Potassium required :", X["K"].min())
    print("Minimum Potassium required :", X["K"].mean())
    print("Maximum Potassium required :", X["K"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Temperature" + "\033[0m")
    print("Minimum Temperature required :", X["temperature"].min())
    print("Minimum Temperature required :", X["temperature"].mean())
    print("Maximum Temperature required :", X["temperature"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Humidity" + "\033[0m")
    print("Minimum Humidity required :", X["humidity"].min())
    print("Minimum Humidity required :", X["humidity"].mean())
    print("Maximum Humidity required :", X["humidity"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for PH" + "\033[0m")
    print("Minimum PH required :", X["ph"].min())
    print("Minimum PH required :", X["ph"].mean())
    print("Maximum PH required :", X["ph"].max())
    
    print("----------------------------------------------")
    print("\033[1m" + "Statistics for Rainfall" + "\033[0m")
    print("Minimum Rainfall required :", X["rainfall"].min())
    print("Minimum Rainfall required :", X["rainfall"].mean())
    print("Maximum Rainfall required :", X["rainfall"].max())
    
    
```


    interactive(children=(Dropdown(description='crops', options=('rice', 'maize', 'jute', 'cotton', 'coconut', 'pa…



```python
#lets compare the Average Requirement for each crops with average conditions
@interact
def compare (Conditions = ["N","P","K","temperature","humidity","ph","rainfall"]):
    print ("Average Value for", Conditions,"is {0:.2f}".format(data[Conditions].mean()))
    print("---------------------------------------------------------")
    print("Apple : {0:.2f}".format(data[(data["label"] == "apple")][Conditions].mean()))
    print("Banana : {0:.2f}".format(data[(data["label"] == "banana")][Conditions].mean()))
    print("Blackgram : {0:.2f}".format(data[(data["label"] == "blackgram")][Conditions].mean()))
    print("Chickpea : {0:.2f}".format(data[(data["label"] == "chickpea")][Conditions].mean()))
    print("Coconut : {0:.2f}".format(data[(data["label"] == "coconut")][Conditions].mean()))
    print("Coffee : {0:.2f}".format(data[(data["label"] == "coffee")][Conditions].mean()))
    print("Cotton : {0:.2f}".format(data[(data["label"] == "cotton")][Conditions].mean()))
    print("Grapes : {0:.2f}".format(data[(data["label"] == "grapes")][Conditions].mean()))
    print("Jute : {0:.2f}".format(data[(data["label"] == "jute")][Conditions].mean()))
    print("Kidneybeans : {0:.2f}".format(data[(data["label"] == "kidneybeans")][Conditions].mean()))
    print("Lentil : {0:.2f}".format(data[(data["label"] == "lentil")][Conditions].mean()))
    print("Maize : {0:.2f}".format(data[(data["label"] == "maize")][Conditions].mean()))
    print("Mango : {0:.2f}".format(data[(data["label"] == "mango")][Conditions].mean()))
    print("Mothbeans : {0:.2f}".format(data[(data["label"] == "mothbeans")][Conditions].mean()))
    print("mungbean : {0:.2f}".format(data[(data["label"] == "mungbean")][Conditions].mean()))
    print("Muskmelon : {0:.2f}".format(data[(data["label"] == "muskmelon")][Conditions].mean()))
    print("Orange : {0:.2f}".format(data[(data["label"] == "orange")][Conditions].mean()))
    print("Papaya : {0:.2f}".format(data[(data["label"] == "papaya")][Conditions].mean()))
    print("Pigeonpeas : {0:.2f}".format(data[(data["label"] == "pigeonpeas")][Conditions].mean()))
    print("Pomegranate : {0:.2f}".format(data[(data["label"] == "pomegranate")][Conditions].mean()))
    print("Rice : {0:.2f}".format(data[(data["label"] == "rice")][Conditions].mean()))
    print("Watermelon : {0:.2f}".format(data[(data["label"] == "watermelon")][Conditions].mean()))




```


    interactive(children=(Dropdown(description='Conditions', options=('N', 'P', 'K', 'temperature', 'humidity', 'p…



```python
#lets make this function more interactive
@interact
def compare (Conditions = ["N","P","K","temperature","humidity","ph","rainfall"]):
    print("\033[1m" +"Crops which require greater than average", Conditions,"\n" + "\033[0m")
    print(data[data[Conditions] > data[Conditions].mean()]["label"].unique())
    print('--------------------------------------------------------------------')
    print("\033[1m" +"Crops which require less than average", Conditions,"\n" + "\033[0m")
    print(data[data[Conditions] <= data[Conditions].mean()]["label"].unique())

```


    interactive(children=(Dropdown(description='Conditions', options=('N', 'P', 'K', 'temperature', 'humidity', 'p…


# Distribution 


```python
## Lets check the Distributionof Agricultural Conditions of dataset
plt.rcParams["figure.figsize"] = (12,7)

plt.subplot(2, 4, 1)
sns.histplot(data["N"], color = "lightgrey")
plt.xlabel("Ratio of Nitrogen", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 2)
sns.histplot(data["P"], color = "blue")
plt.xlabel("Ratio of Phosphorous", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 3)
sns.histplot(data["K"], color = "darkblue")
plt.xlabel("Ratio of Potassium", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 4)
sns.histplot(data["temperature"], color = "lightgreen")
plt.xlabel("Ratio of Temperature", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 5)
sns.histplot(data["humidity"], color = "darkgreen")
plt.xlabel("Ratio of Humidity", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 6)
sns.histplot(data["ph"], color = "red")
plt.xlabel("Ratio of PH", fontsize = 12)
plt.grid()

plt.subplot(2, 4, 7)
sns.histplot(data["rainfall"], color = "black")
plt.xlabel("Ratio of Rainfall", fontsize = 12)
plt.grid()
```


    
![png](output_12_0.png)
    



```python
# Lets find out some Interesting Facts

print("Some Interesting Patterns")
print("-----------------------------------------------------------------------------------------------------")
print("Crops which require very High Ratio of Nitrogen Content in Soil:", data[data["N"]>120]["label"].unique())
print("Crops which require very High Ratio of Phosphorous Content in Soil:", data[data["P"]>100]["label"].unique())
print("Crops which require very High Ratio of Potassium Content in Soil:", data[data["K"]>200]["label"].unique())
print("Crops which require very High Rainfall:", data[data["rainfall"]>200]["label"].unique())
print("Crops which require very Low Temperature:", data[data["temperature"]<10]["label"].unique())
print("Crops which require very High Temperature:", data[data["temperature"]>40]["label"].unique())
print("Crops which require very Low Humidity:", data[data["humidity"]<20]["label"].unique())
print("Crops which require very High PH:", data[data["ph"]>9]["label"].unique())
print("Crops which require very Low PH:", data[data["ph"]<4]["label"].unique())




```

    Some Interesting Patterns
    -----------------------------------------------------------------------------------------------------
    Crops which require very High Ratio of Nitrogen Content in Soil: ['cotton']
    Crops which require very High Ratio of Phosphorous Content in Soil: ['grapes' 'apple']
    Crops which require very High Ratio of Potassium Content in Soil: ['grapes' 'apple']
    Crops which require very High Rainfall: ['rice' 'papaya' 'coconut']
    Crops which require very Low Temperature: ['grapes']
    Crops which require very High Temperature: ['grapes' 'papaya']
    Crops which require very Low Humidity: ['chickpea' 'kidneybeans']
    Crops which require very High PH: ['mothbeans']
    Crops which require very Low PH: ['mothbeans']
    


```python
# Lets understand which crops can only be Grown in Summer, Wnter and Rainy Season

print ("\033[1m" +"Summer Crops"+ "\033[0m")

print(data[(data["temperature"]>30)&(data["humidity"]>50)]["label"].unique(),"\n")

print ("\033[1m" +"Winter Crops"+ "\033[0m")
print(data[(data["temperature"]<20)&(data["humidity"]>30)]["label"].unique(),"\n")

print ("\033[1m" +"Rainy Crops"+ "\033[0m")
print(data[(data["rainfall"]>200)&(data["humidity"]>30)]["label"].unique())
```

    [1mSummer Crops[0m
    ['pigeonpeas' 'mothbeans' 'blackgram' 'mango' 'grapes' 'orange' 'papaya'] 
    
    [1mWinter Crops[0m
    ['maize' 'pigeonpeas' 'lentil' 'pomegranate' 'grapes' 'orange'] 
    
    [1mRainy Crops[0m
    ['rice' 'papaya' 'coconut']
    


```python
#Lets Cluster Crops 
#Lets import the warning libraries so that we can avoid warning

from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings("ignore")

#lets select Colums from the Dataset
x = data.loc[:,["N","P","K","temperature","humidity","ph","rainfall"]].values

#Let's check the shape of x
print(x.shape)

#Lets convert this data into a dataframe
x_data = pd.DataFrame(x)
x_data.head()

```

    (2200, 7)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>90.0</td>
      <td>42.0</td>
      <td>43.0</td>
      <td>20.879744</td>
      <td>82.002744</td>
      <td>6.502985</td>
      <td>202.935536</td>
    </tr>
    <tr>
      <th>1</th>
      <td>85.0</td>
      <td>58.0</td>
      <td>41.0</td>
      <td>21.770462</td>
      <td>80.319644</td>
      <td>7.038096</td>
      <td>226.655537</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60.0</td>
      <td>55.0</td>
      <td>44.0</td>
      <td>23.004459</td>
      <td>82.320763</td>
      <td>7.840207</td>
      <td>263.964248</td>
    </tr>
    <tr>
      <th>3</th>
      <td>74.0</td>
      <td>35.0</td>
      <td>40.0</td>
      <td>26.491096</td>
      <td>80.158363</td>
      <td>6.980401</td>
      <td>242.864034</td>
    </tr>
    <tr>
      <th>4</th>
      <td>78.0</td>
      <td>42.0</td>
      <td>42.0</td>
      <td>20.130175</td>
      <td>81.604873</td>
      <td>7.628473</td>
      <td>262.717340</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Lets determine the optimum Number of Clusters within the Dataset

plt.rcParams["figure.figsize"] = (10,4)

WCSS = []
for i in range(1,11):
    km = KMeans(n_clusters = i, init = "k-means++", max_iter = 300, n_init = 10, random_state = 0)
    km.fit(x)
    WCSS.append(km.inertia_)
    
#Lets plot the result
#Please note that on the chart below we have two Elbows, one ate 3 and another one at 4. we are going to use the greatest 4
plt.plot(range(1,11), WCSS)
plt.title("The Elbow Method", fontsize = 20)
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")
plt.show()
```


    
![png](output_16_0.png)
    



```python
#Next we are going to implement the K Means algorithm to perform clustering analysis
km = KMeans(n_clusters = 4, init = "k-means++", max_iter = 300, n_init = 10, random_state = 0)
y_means = km.fit_predict(x)

#Lets find out the results
a = data["label"]
y_means = pd.DataFrame(y_means)
z = pd.concat([y_means, a], axis = 1)
z = z.rename(columns ={0:"cluster"})

#Lets check the Clusters of each Crops
print("Lets check the Results After Applying the K Means Clustering Analysis \n")
print("Crops in First Cluster:", z[z["cluster"] == 0]["label"].unique())
print("--------------------------------------------------------------------------")
print("Crops in Second Cluster:", z[z["cluster"] == 1]["label"].unique())
print("--------------------------------------------------------------------------")
print("Crops in Third Cluster:", z[z["cluster"] == 2]["label"].unique())
print("--------------------------------------------------------------------------")
print("Crops in Fourth Cluster:", z[z["cluster"] == 3]["label"].unique())
```

    Lets check the Results After Applying the K Means Clustering Analysis 
    
    Crops in First Cluster: ['grapes' 'apple']
    --------------------------------------------------------------------------
    Crops in Second Cluster: ['maize' 'banana' 'watermelon' 'muskmelon' 'papaya' 'cotton' 'coffee']
    --------------------------------------------------------------------------
    Crops in Third Cluster: ['rice' 'pigeonpeas' 'papaya' 'coconut' 'jute' 'coffee']
    --------------------------------------------------------------------------
    Crops in Fourth Cluster: ['maize' 'chickpea' 'kidneybeans' 'pigeonpeas' 'mothbeans' 'mungbean'
     'blackgram' 'lentil' 'pomegranate' 'mango' 'orange' 'papaya' 'coconut']
    


```python
#Lets build a predictive Module to help farmers deide the type of Crops given climate and soil conditions.
#Lets split the Dataset from Predictive Modeling

y = data["label"]
x = data.drop(["label"], axis = 1)

print("Shape of x:", x.shape)
print("Shape of y:", y.shape)
```

    Shape of x: (2200, 7)
    Shape of y: (2200,)
    


```python
#Now we are creating Training and Testing Sets for Validation of Results
from sklearn.model_selection import train_test_split

x_train, x_test, y_train,y_test = train_test_split(x,y, test_size = 0.2, random_state =0)
print("The Shape of x train:", x_train.shape)
print("The Shape of x test:", x_test.shape)
print("The Shape of y train:", y_train.shape)
print("The Shape of y test:", y_test.shape)
```

    The Shape of x train: (1760, 7)
    The Shape of x test: (440, 7)
    The Shape of y train: (1760,)
    The Shape of y test: (440,)
    


```python
#Next we build a Predictive Model
from sklearn.linear_model import LogisticRegression

model = LogisticRegression()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
```


```python
#Lets evaluate the Model Performance
from sklearn.metrics import classification_report

#Lets print the classification Report as well
#this table gives us the accuracy of the model, greater value of the Precision and Recall = better the Model
cr = classification_report(y_test,y_pred)
print(cr)
```

                  precision    recall  f1-score   support
    
           apple       1.00      1.00      1.00        18
          banana       1.00      1.00      1.00        18
       blackgram       0.86      0.82      0.84        22
        chickpea       1.00      1.00      1.00        23
         coconut       1.00      1.00      1.00        15
          coffee       1.00      1.00      1.00        17
          cotton       0.89      1.00      0.94        16
          grapes       1.00      1.00      1.00        18
            jute       0.84      1.00      0.91        21
     kidneybeans       1.00      1.00      1.00        20
          lentil       0.94      0.94      0.94        17
           maize       0.94      0.89      0.91        18
           mango       1.00      1.00      1.00        21
       mothbeans       0.88      0.92      0.90        25
        mungbean       1.00      1.00      1.00        17
       muskmelon       1.00      1.00      1.00        23
          orange       1.00      1.00      1.00        23
          papaya       1.00      0.95      0.98        21
      pigeonpeas       1.00      1.00      1.00        22
     pomegranate       1.00      1.00      1.00        23
            rice       1.00      0.84      0.91        25
      watermelon       1.00      1.00      1.00        17
    
        accuracy                           0.97       440
       macro avg       0.97      0.97      0.97       440
    weighted avg       0.97      0.97      0.97       440
    
    


```python
#Now we are done with testing, now we are going to do predictions. First we check the head of the dataset
data.head()


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>N</th>
      <th>P</th>
      <th>K</th>
      <th>temperature</th>
      <th>humidity</th>
      <th>ph</th>
      <th>rainfall</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>90</td>
      <td>42</td>
      <td>43</td>
      <td>20.879744</td>
      <td>82.002744</td>
      <td>6.502985</td>
      <td>202.935536</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>1</th>
      <td>85</td>
      <td>58</td>
      <td>41</td>
      <td>21.770462</td>
      <td>80.319644</td>
      <td>7.038096</td>
      <td>226.655537</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>55</td>
      <td>44</td>
      <td>23.004459</td>
      <td>82.320763</td>
      <td>7.840207</td>
      <td>263.964248</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>3</th>
      <td>74</td>
      <td>35</td>
      <td>40</td>
      <td>26.491096</td>
      <td>80.158363</td>
      <td>6.980401</td>
      <td>242.864034</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>4</th>
      <td>78</td>
      <td>42</td>
      <td>42</td>
      <td>20.130175</td>
      <td>81.604873</td>
      <td>7.628473</td>
      <td>262.717340</td>
      <td>rice</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Here input the values to generate predictions
prediction = model.predict((np.array([[78,
                                       50,
                                       43,
                                       30,
                                       100,
                                       8,
                                       100]])))
print("The Sugested Crop for Given Climatic Condition is :", prediction)
```

    The Sugested Crop for Given Climatic Condition is : ['jute']
    


```python
#Now we are done with testing, now we are going to do predictions. First we check the head of the dataset
data.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>N</th>
      <th>P</th>
      <th>K</th>
      <th>temperature</th>
      <th>humidity</th>
      <th>ph</th>
      <th>rainfall</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>90</td>
      <td>42</td>
      <td>43</td>
      <td>20.879744</td>
      <td>82.002744</td>
      <td>6.502985</td>
      <td>202.935536</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>1</th>
      <td>85</td>
      <td>58</td>
      <td>41</td>
      <td>21.770462</td>
      <td>80.319644</td>
      <td>7.038096</td>
      <td>226.655537</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>2</th>
      <td>60</td>
      <td>55</td>
      <td>44</td>
      <td>23.004459</td>
      <td>82.320763</td>
      <td>7.840207</td>
      <td>263.964248</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>3</th>
      <td>74</td>
      <td>35</td>
      <td>40</td>
      <td>26.491096</td>
      <td>80.158363</td>
      <td>6.980401</td>
      <td>242.864034</td>
      <td>rice</td>
    </tr>
    <tr>
      <th>4</th>
      <td>78</td>
      <td>42</td>
      <td>42</td>
      <td>20.130175</td>
      <td>81.604873</td>
      <td>7.628473</td>
      <td>262.717340</td>
      <td>rice</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Here input the values to generate predictions
prediction = model.predict((np.array([[20,
                                       30,
                                       10,
                                       15,
                                       90,
                                       7.5,
                                       100]])))
print("The Sugested Crop for Given Climatic Condition is :", prediction)
```

    The Sugested Crop for Given Climatic Condition is : ['orange']
    
